/**
 * PORTAL 4 — MDF-e Notícias SVRS
 * URL: https://dfe-portal.svrs.rs.gov.br/Mdfe/Noticias
 * Estrutura: blocos longos de texto com NTs, comunicados, implantações
 * Método: axios + cheerio (com fallback Puppeteer)
 */
const axios = require("axios");
const cheerio = require("cheerio");
const { extrairData, isHoje, hojeStr } = require("../utils/date");
const log = require("../utils/logger");

const PORTAL = {
  nome: "MDF-e Notícias",
  url: "https://dfe-portal.svrs.rs.gov.br/Mdfe/Noticias",
};

const HEADERS = {
  "User-Agent": "Auditec-Curador/1.0 (Fiscal Compliance)",
  Accept: "text/html,application/xhtml+xml",
};

function autoTags(titulo) {
  const t = (titulo || "").toLowerCase();
  const tags = ["MDF-e"];
  if (/nota\s+t[eé]cnica|nt\s+\d/i.test(t)) tags.push("NT");
  if (/schema|xsd/i.test(t)) tags.push("schema");
  if (/ibs/i.test(t)) tags.push("IBS");
  if (/cbs/i.test(t)) tags.push("CBS");
  if (/rtc|reforma/i.test(t)) tags.push("RTC");
  if (/homologa/i.test(t)) tags.push("homologação");
  if (/produ[çc][ãa]o/i.test(t)) tags.push("produção");
  if (/valida/i.test(t)) tags.push("validação");
  return tags;
}

function tipoConteudo(titulo) {
  const t = (titulo || "").toLowerCase();
  if (/nota\s+t[eé]cnica/i.test(t)) return "nota técnica";
  if (/schema/i.test(t)) return "schema";
  if (/homologa/i.test(t)) return "implantação homologação";
  if (/produ[çc][ãa]o/i.test(t)) return "implantação produção";
  if (/valida/i.test(t)) return "regra de validação";
  return "comunicado";
}

/**
 * Separa o conteúdo em blocos individuais por data ou título.
 * O portal MDF-e tende a ter texto corrido, então precisamos de heurística.
 */
function segmentarBlocos(texto) {
  const blocos = [];
  // Tentar separar por padrão "DD/MM/YYYY" no início de linha
  const partes = texto.split(/(?=\d{2}\/\d{2}\/\d{4})/);

  for (const parte of partes) {
    const t = parte.trim();
    if (!t || t.length < 15) continue;

    const data = extrairData(t);
    if (!data) continue;

    // O título é tudo até o próximo ponto ou quebra longa
    const semData = t.replace(/^\d{2}\/\d{2}\/\d{4}\s*[-–—:.]?\s*/, "");
    const titulo = semData.split(/[.\n]/, 1)[0].trim();

    if (titulo.length < 10) continue;

    blocos.push({ data, titulo, textoCompleto: semData.slice(0, 500) });
  }

  return blocos;
}

async function coletar() {
  const resultado = {
    nome: PORTAL.nome,
    url: PORTAL.url,
    consultadoEm: "",
    encontrouItensHoje: false,
    itens: [],
    observacoes: "",
    erro: null,
  };

  log.info(`Verificando ${PORTAL.nome}...`);

  let html;
  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      const resp = await axios.get(PORTAL.url, { headers: HEADERS, timeout: 30000 });
      html = resp.data;
      break;
    } catch (err) {
      if (attempt === 2) {
        resultado.erro = `Falha após 2 tentativas: ${err.message}`;
        log.error(`  ✗ ${PORTAL.nome}: ${resultado.erro}`);
        return resultado;
      }
      await new Promise((r) => setTimeout(r, 2000));
    }
  }

  resultado.consultadoEm = new Date().toISOString();

  try {
    const $ = cheerio.load(html);

    // Estratégia 1: buscar links com data
    const seen = new Set();
    $("a[href]").each((_, el) => {
      const a = $(el);
      const href = a.attr("href") || "";
      const titulo = a.text().trim();
      if (!titulo || titulo.length < 10 || seen.has(titulo)) return;
      seen.add(titulo);

      const parent = a.closest("div, li, tr, article");
      let data = null;
      if (parent.length) data = extrairData(parent.text());
      if (!data) data = extrairData(titulo);

      if (data && isHoje(data)) {
        let fullHref = href;
        if (fullHref.startsWith("/")) fullHref = "https://dfe-portal.svrs.rs.gov.br" + fullHref;

        resultado.itens.push({
          titulo: titulo.replace(/\s+/g, " "),
          dataPublicacao: data,
          url: fullHref,
          resumoCurto: titulo.split(/\s+/).slice(0, 50).join(" "),
          tags: autoTags(titulo),
          portalOrigem: PORTAL.nome,
          tipoConteudo: tipoConteudo(titulo),
          confianca: "alta",
        });
      }
    });

    // Estratégia 2: segmentar texto corrido do body
    if (resultado.itens.length === 0) {
      const content = $("main, #content, .content, body").first().text();
      const blocos = segmentarBlocos(content);

      for (const bloco of blocos) {
        if (!isHoje(bloco.data)) continue;
        if (seen.has(bloco.titulo)) continue;
        seen.add(bloco.titulo);

        resultado.itens.push({
          titulo: bloco.titulo.replace(/\s+/g, " "),
          dataPublicacao: bloco.data,
          url: PORTAL.url,
          resumoCurto: bloco.textoCompleto.split(/\s+/).slice(0, 50).join(" "),
          tags: autoTags(bloco.titulo),
          portalOrigem: PORTAL.nome,
          tipoConteudo: tipoConteudo(bloco.titulo),
          confianca: "média",
        });
      }
    }

    resultado.encontrouItensHoje = resultado.itens.length > 0;
    if (!resultado.encontrouItensHoje) {
      resultado.observacoes = `Portal verificado com sucesso. Sem publicações para ${hojeStr()}.`;
    }

    log.info(`  → ${PORTAL.nome}: ${resultado.itens.length} item(ns) de hoje`);
  } catch (err) {
    resultado.erro = `Erro no parsing: ${err.message}`;
    log.error(`  ✗ ${PORTAL.nome}: ${resultado.erro}`);
  }

  return resultado;
}

module.exports = { coletar };
