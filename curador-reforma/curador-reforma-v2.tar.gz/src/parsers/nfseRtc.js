/**
 * PORTAL 7 — NFS-e RTC (Documentação Técnica)
 * URL: https://www.gov.br/nfse/pt-br/biblioteca/documentacao-tecnica/rtc
 * Estrutura: biblioteca documental gov.br (NTs, manuais, layouts)
 * Método: axios + cheerio (estrutura variável gov.br)
 */
const axios = require("axios");
const cheerio = require("cheerio");
const { extrairData, isHoje, hojeStr } = require("../utils/date");
const log = require("../utils/logger");

const PORTAL = {
  nome: "NFS-e RTC",
  url: "https://www.gov.br/nfse/pt-br/biblioteca/documentacao-tecnica/rtc",
};

const HEADERS = {
  "User-Agent": "Auditec-Curador/1.0 (Fiscal Compliance)",
  Accept: "text/html,application/xhtml+xml",
};

function autoTags(titulo) {
  const t = (titulo || "").toLowerCase();
  const tags = [];
  if (/nfs-?e/i.test(t)) tags.push("NFS-e");
  if (/rtc|reforma/i.test(t)) tags.push("RTC");
  if (/ibs/i.test(t)) tags.push("IBS");
  if (/cbs/i.test(t)) tags.push("CBS");
  if (/nota\s+t[eé]cnica|nt\s+\d/i.test(t)) tags.push("NT");
  if (/manual/i.test(t)) tags.push("manual");
  if (/leiaute|layout/i.test(t)) tags.push("leiaute");
  if (/schema|xsd/i.test(t)) tags.push("schema");
  if (/documento\s+t[eé]cnico/i.test(t)) tags.push("documento técnico");
  return tags.length ? tags : ["NFS-e", "RTC"];
}

async function coletar() {
  const resultado = {
    nome: PORTAL.nome,
    url: PORTAL.url,
    consultadoEm: "",
    encontrouItensHoje: false,
    itens: [],
    observacoes: "",
    erro: null,
  };

  log.info(`Verificando ${PORTAL.nome}...`);

  let html;
  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      const resp = await axios.get(PORTAL.url, { headers: HEADERS, timeout: 30000 });
      html = resp.data;
      break;
    } catch (err) {
      if (attempt === 2) {
        resultado.erro = `Falha após 2 tentativas: ${err.message}`;
        log.error(`  ✗ ${PORTAL.nome}: ${resultado.erro}`);
        return resultado;
      }
      await new Promise((r) => setTimeout(r, 2000));
    }
  }

  resultado.consultadoEm = new Date().toISOString();

  try {
    const $ = cheerio.load(html);
    const seen = new Set();

    // Seletores gov.br — múltiplas tentativas
    const seletores = [
      "article", ".tileItem", ".tile-content", ".listagem-item",
      "li.item", ".news-item", ".resultado",
    ];

    let articles = [];
    for (const sel of seletores) {
      articles = $(sel).toArray();
      if (articles.length > 0) break;
    }

    // Fallback: conteúdo principal
    if (articles.length === 0) {
      const content = $("#content, main, .content-area").first();
      if (content.length) {
        articles = content.find("article, li, div").toArray();
      }
    }

    for (const el of articles) {
      const $el = $(el);
      const a = $el.is("a") ? $el : $el.find("a[href]").first();
      if (!a.length) continue;

      let href = (a.attr("href") || "").trim();
      const titulo = a.text().replace(/\s+/g, " ").trim();

      if (!titulo || titulo.length < 10 || seen.has(titulo)) continue;
      seen.add(titulo);

      if (href.startsWith("/")) href = "https://www.gov.br" + href;
      if (!href.startsWith("http")) continue;

      // Buscar data
      let data = null;

      // Elementos semânticos
      const dateEls = [".date", ".data", "time", "span.publicado", ".tileDate"];
      for (const sel of dateEls) {
        const dateEl = $el.find(sel).first();
        if (dateEl.length) {
          const dt = dateEl.attr("datetime") || dateEl.text();
          data = extrairData(dt);
          if (data) break;
        }
      }

      // Fallback: texto do pai
      if (!data) data = extrairData($el.text());

      // Fallback: URL com data
      if (!data) data = extrairData(href);

      if (!data || !isHoje(data)) continue;

      // Resumo do elemento
      const pEl = $el.find(".descricao, .description, .resumo, p").first();
      const resumo = pEl.length ? pEl.text().trim().slice(0, 300) : "";

      resultado.itens.push({
        titulo,
        dataPublicacao: data,
        url: href,
        resumoCurto: (resumo || titulo).split(/\s+/).slice(0, 50).join(" "),
        tags: autoTags(titulo),
        portalOrigem: PORTAL.nome,
        tipoConteudo: /nota\s+t[eé]cnica/i.test(titulo) ? "nota técnica" : "documento técnico",
        confianca: "alta",
      });
    }

    resultado.encontrouItensHoje = resultado.itens.length > 0;
    if (!resultado.encontrouItensHoje) {
      resultado.observacoes = `Portal verificado com sucesso. Sem publicações para ${hojeStr()}.`;
    }

    log.info(`  → ${PORTAL.nome}: ${resultado.itens.length} item(ns) de hoje`);
  } catch (err) {
    resultado.erro = `Erro no parsing: ${err.message}`;
    log.error(`  ✗ ${PORTAL.nome}: ${resultado.erro}`);
  }

  return resultado;
}

module.exports = { coletar };
