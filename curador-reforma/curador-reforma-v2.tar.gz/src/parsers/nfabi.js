/**
 * PORTAL 5 — NFABI Documentos
 * URL: https://dfe-portal.svrs.rs.gov.br/Nfabi/Documentos
 * Estrutura: documentação técnica (manuais, anexos, leiautes, tabelas RTC)
 * Método: axios + cheerio
 */
const axios = require("axios");
const cheerio = require("cheerio");
const { extrairData, isHoje, hojeStr } = require("../utils/date");
const log = require("../utils/logger");

const PORTAL = {
  nome: "NFABI Documentos",
  url: "https://dfe-portal.svrs.rs.gov.br/Nfabi/Documentos",
};

const HEADERS = {
  "User-Agent": "Auditec-Curador/1.0 (Fiscal Compliance)",
  Accept: "text/html,application/xhtml+xml",
};

function autoTags(titulo) {
  const t = (titulo || "").toLowerCase();
  const tags = ["NFABI"];
  if (/rtc|reforma/i.test(t)) tags.push("RTC");
  if (/cst|cclasstrib/i.test(t)) tags.push("CST");
  if (/cr[eé]dito\s+presumido/i.test(t)) tags.push("crédito presumido");
  if (/manual/i.test(t)) tags.push("manual");
  if (/anexo/i.test(t)) tags.push("anexo");
  if (/leiaute|layout/i.test(t)) tags.push("leiaute");
  if (/nota\s+t[eé]cnica/i.test(t)) tags.push("NT");
  if (/tabela/i.test(t)) tags.push("tabela");
  if (/ibs/i.test(t)) tags.push("IBS");
  if (/cbs/i.test(t)) tags.push("CBS");
  return tags;
}

async function coletar() {
  const resultado = {
    nome: PORTAL.nome,
    url: PORTAL.url,
    consultadoEm: "",
    encontrouItensHoje: false,
    itens: [],
    observacoes: "",
    erro: null,
  };

  log.info(`Verificando ${PORTAL.nome}...`);

  let html;
  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      const resp = await axios.get(PORTAL.url, { headers: HEADERS, timeout: 30000 });
      html = resp.data;
      break;
    } catch (err) {
      if (attempt === 2) {
        resultado.erro = `Falha após 2 tentativas: ${err.message}`;
        log.error(`  ✗ ${PORTAL.nome}: ${resultado.erro}`);
        return resultado;
      }
      await new Promise((r) => setTimeout(r, 2000));
    }
  }

  resultado.consultadoEm = new Date().toISOString();

  try {
    const $ = cheerio.load(html);
    const seen = new Set();

    // Buscar links de documentos
    $("a[href]").each((_, el) => {
      const a = $(el);
      let href = (a.attr("href") || "").trim();
      const titulo = a.text().replace(/\s+/g, " ").trim();

      if (!titulo || titulo.length < 8 || seen.has(titulo)) return;
      seen.add(titulo);

      if (href.startsWith("/")) href = "https://dfe-portal.svrs.rs.gov.br" + href;

      // Buscar data no pai
      const parent = a.closest("tr, li, div, article");
      let data = null;
      if (parent.length) {
        parent.find("td, span, time").each((_, td) => {
          if (!data) data = extrairData($(td).text());
        });
        if (!data) data = extrairData(parent.text());
      }

      if (!data || !isHoje(data)) return;

      resultado.itens.push({
        titulo,
        dataPublicacao: data,
        url: href,
        resumoCurto: titulo.split(/\s+/).slice(0, 50).join(" "),
        tags: autoTags(titulo),
        portalOrigem: PORTAL.nome,
        tipoConteudo: /manual/i.test(titulo) ? "manual" : /anexo/i.test(titulo) ? "anexo" : "documento técnico",
        confianca: "alta",
      });
    });

    // Fallback: buscar datas no texto corrido
    if (resultado.itens.length === 0) {
      const texto = $("main, #content, .content, body").first().text();
      const re = /(\d{2}\/\d{2}\/\d{4})\s*[-–—:.]?\s*(.{15,200})/g;
      let m;
      while ((m = re.exec(texto)) !== null) {
        const data = m[1];
        if (!isHoje(data)) continue;
        const titulo = m[2].split(/[.\n]/, 1)[0].trim();
        if (titulo.length < 10 || seen.has(titulo)) continue;
        seen.add(titulo);

        resultado.itens.push({
          titulo,
          dataPublicacao: data,
          url: PORTAL.url,
          resumoCurto: titulo.split(/\s+/).slice(0, 50).join(" "),
          tags: autoTags(titulo),
          portalOrigem: PORTAL.nome,
          tipoConteudo: "documento técnico",
          confianca: "média",
        });
      }
    }

    resultado.encontrouItensHoje = resultado.itens.length > 0;
    if (!resultado.encontrouItensHoje) {
      resultado.observacoes = `Portal verificado com sucesso. Sem publicações para ${hojeStr()}.`;
    }

    log.info(`  → ${PORTAL.nome}: ${resultado.itens.length} item(ns) de hoje`);
  } catch (err) {
    resultado.erro = `Erro no parsing: ${err.message}`;
    log.error(`  ✗ ${PORTAL.nome}: ${resultado.erro}`);
  }

  return resultado;
}

module.exports = { coletar };
