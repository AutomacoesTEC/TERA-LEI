/**
 * PORTAL 1 — CT-e Informes
 * URL: https://www.cte.fazenda.gov.br/portal/informe.aspx
 * Estrutura: lista cronológica simples "DD/MM/YYYY - Título..."
 * Método: axios + cheerio (HTML estático)
 */
const axios = require("axios");
const cheerio = require("cheerio");
const { extrairData, isHoje, hojeStr } = require("../utils/date");
const log = require("../utils/logger");

const PORTAL = {
  nome: "CT-e Informes",
  url: "https://www.cte.fazenda.gov.br/portal/informe.aspx",
};

const HEADERS = {
  "User-Agent": "Auditec-Curador/1.0 (Fiscal Compliance)",
  Accept: "text/html,application/xhtml+xml",
  "Accept-Language": "pt-BR,pt;q=0.9",
};

function autoTags(titulo) {
  const t = (titulo || "").toLowerCase();
  const tags = [];
  if (/ct-?e/i.test(t)) tags.push("CT-e");
  if (/nota\s+t[eé]cnica|nt\s+\d/i.test(t)) tags.push("NT");
  if (/schema|xsd/i.test(t)) tags.push("schema");
  if (/ibs/i.test(t)) tags.push("IBS");
  if (/cbs/i.test(t)) tags.push("CBS");
  if (/rtc|reforma/i.test(t)) tags.push("RTC");
  if (/df-?e/i.test(t)) tags.push("DF-e");
  return tags.length ? tags : ["CT-e"];
}

function tipoConteudo(titulo) {
  const t = (titulo || "").toLowerCase();
  if (/nota\s+t[eé]cnica/i.test(t)) return "nota técnica";
  if (/schema/i.test(t)) return "schema";
  if (/vers[ãa]o/i.test(t)) return "atualização de versão";
  return "comunicado";
}

function resumoCurto(titulo) {
  const words = (titulo || "").split(/\s+/).slice(0, 50);
  return words.join(" ");
}

async function coletar() {
  const resultado = {
    nome: PORTAL.nome,
    url: PORTAL.url,
    consultadoEm: "",
    encontrouItensHoje: false,
    itens: [],
    observacoes: "",
    erro: null,
  };

  log.info(`Verificando ${PORTAL.nome}...`);

  let html;
  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      const resp = await axios.get(PORTAL.url, {
        headers: HEADERS,
        timeout: 30000,
      });
      html = resp.data;
      break;
    } catch (err) {
      if (attempt === 2) {
        resultado.erro = `Falha após 2 tentativas: ${err.message}`;
        log.error(`  ✗ ${PORTAL.nome}: ${resultado.erro}`);
        return resultado;
      }
      log.warn(`  ⏱ ${PORTAL.nome}: tentativa ${attempt} falhou, retentando...`);
      await new Promise((r) => setTimeout(r, 2000));
    }
  }

  resultado.consultadoEm = new Date().toISOString();

  try {
    const $ = cheerio.load(html);
    const body = $("body").text();

    // Regex: captura blocos "DD/MM/YYYY - Texto..."
    const re = /(\d{2}\/\d{2}\/\d{4})\s*[-–—]\s*(.+?)(?=\d{2}\/\d{2}\/\d{4}\s*[-–—]|$)/gs;
    let match;

    while ((match = re.exec(body)) !== null) {
      const data = match[1].trim();
      const titulo = match[2].replace(/\s+/g, " ").trim();

      if (!titulo || titulo.length < 10) continue;
      if (!isHoje(data)) continue;

      resultado.itens.push({
        titulo,
        dataPublicacao: data,
        url: PORTAL.url,
        resumoCurto: resumoCurto(titulo),
        tags: autoTags(titulo),
        portalOrigem: PORTAL.nome,
        tipoConteudo: tipoConteudo(titulo),
        confianca: "alta",
      });
    }

    resultado.encontrouItensHoje = resultado.itens.length > 0;
    if (!resultado.encontrouItensHoje) {
      resultado.observacoes = `Portal verificado com sucesso. Sem publicações para ${hojeStr()}.`;
    }

    log.info(`  → ${PORTAL.nome}: ${resultado.itens.length} item(ns) de hoje`);
  } catch (err) {
    resultado.erro = `Erro no parsing: ${err.message}`;
    log.error(`  ✗ ${PORTAL.nome}: ${resultado.erro}`);
  }

  return resultado;
}

module.exports = { coletar };
