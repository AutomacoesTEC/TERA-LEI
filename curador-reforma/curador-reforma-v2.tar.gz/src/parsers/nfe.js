/**
 * PORTAL 2 — NF-e Documentos Vigentes
 * URL: https://www.nfe.fazenda.gov.br/portal/listaConteudo.aspx?tipoConteudo=04BIflQt1aY=
 * Estrutura: listas longas de NTs separadas em "vigentes" e "não vigentes"
 * Método: axios + cheerio (HTML estático)
 */
const axios = require("axios");
const cheerio = require("cheerio");
const { extrairData, isHoje, hojeStr } = require("../utils/date");
const log = require("../utils/logger");

const PORTAL = {
  nome: "NF-e Notas Técnicas",
  url: "https://www.nfe.fazenda.gov.br/portal/listaConteudo.aspx?tipoConteudo=04BIflQt1aY=",
};

const HEADERS = {
  "User-Agent": "Auditec-Curador/1.0 (Fiscal Compliance)",
  Accept: "text/html,application/xhtml+xml",
};

function autoTags(titulo) {
  const t = (titulo || "").toLowerCase();
  const tags = [];
  if (/nf-?e/i.test(t)) tags.push("NF-e");
  if (/nota\s+t[eé]cnica|nt\s+\d/i.test(t)) tags.push("NT");
  if (/schema|xsd/i.test(t)) tags.push("schema");
  if (/ibs/i.test(t)) tags.push("IBS");
  if (/cbs/i.test(t)) tags.push("CBS");
  if (/rtc|reforma/i.test(t)) tags.push("RTC");
  if (/leiaute|layout/i.test(t)) tags.push("leiaute");
  return tags.length ? tags : ["NF-e"];
}

function extrairVersao(titulo) {
  const m = titulo.match(/v\.?\s*(\d+\.\d+)/i);
  return m ? m[1] : null;
}

function extrairNumeroNT(titulo) {
  const m = titulo.match(/(?:Nota\s+T[eé]cnica|NT)\s+(\d{4}\.\d{3})/i);
  return m ? m[1] : null;
}

async function coletar() {
  const resultado = {
    nome: PORTAL.nome,
    url: PORTAL.url,
    consultadoEm: "",
    encontrouItensHoje: false,
    itens: [],
    observacoes: "",
    erro: null,
  };

  log.info(`Verificando ${PORTAL.nome}...`);

  let html;
  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      const resp = await axios.get(PORTAL.url, {
        headers: HEADERS,
        timeout: 30000,
      });
      html = resp.data;
      break;
    } catch (err) {
      if (attempt === 2) {
        resultado.erro = `Falha após 2 tentativas: ${err.message}`;
        log.error(`  ✗ ${PORTAL.nome}: ${resultado.erro}`);
        return resultado;
      }
      await new Promise((r) => setTimeout(r, 2000));
    }
  }

  resultado.consultadoEm = new Date().toISOString();

  try {
    const $ = cheerio.load(html);

    // Processar todos os links da página
    const seen = new Set();

    $("a").each((_, el) => {
      const a = $(el);
      let href = (a.attr("href") || "").trim();
      const texto = a.text().trim();

      if (!texto || texto.length < 10) return;
      if (href.startsWith("/")) href = "https://www.nfe.fazenda.gov.br" + href;
      else if (!href.startsWith("http")) href = "https://www.nfe.fazenda.gov.br/portal/" + href;
      if (seen.has(href)) return;
      seen.add(href);

      // Extrair data do texto do link ou do pai
      let data = null;

      // Padrão "Publicada em DD/MM/YYYY"
      const pubMatch = texto.match(/[Pp]ublicada?\s+em\s+(\d{2}\/\d{2}\/\d{4})/);
      if (pubMatch) data = pubMatch[1];

      // Fallback: buscar no elemento pai (tr ou div)
      if (!data) {
        const parent = a.closest("tr, li, div");
        if (parent.length) {
          parent.find("td, span").each((_, td) => {
            if (!data) data = extrairData($(td).text());
          });
        }
      }

      if (!data || !isHoje(data)) return;

      const ntNum = extrairNumeroNT(texto);
      const versao = extrairVersao(texto);
      const titulo = texto.replace(/\s+/g, " ");

      resultado.itens.push({
        titulo,
        dataPublicacao: data,
        url: href,
        resumoCurto: titulo.split(/\s+/).slice(0, 50).join(" "),
        tags: autoTags(titulo),
        portalOrigem: PORTAL.nome,
        tipoConteudo: ntNum ? "nota técnica" : "documento técnico",
        confianca: "alta",
        _meta: { ntNumero: ntNum, versao },
      });
    });

    resultado.encontrouItensHoje = resultado.itens.length > 0;
    if (!resultado.encontrouItensHoje) {
      resultado.observacoes = `Portal verificado com sucesso. Sem publicações para ${hojeStr()}.`;
    }

    log.info(`  → ${PORTAL.nome}: ${resultado.itens.length} item(ns) de hoje`);
  } catch (err) {
    resultado.erro = `Erro no parsing: ${err.message}`;
    log.error(`  ✗ ${PORTAL.nome}: ${resultado.erro}`);
  }

  return resultado;
}

module.exports = { coletar };
