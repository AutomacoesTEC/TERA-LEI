/**
 * PORTAL 6 — BP-e Notícias
 * URL: https://dfe-portal.svrs.rs.gov.br/Bpe/Noticias
 * Estrutura: notícias, comunicados, versões, consultas públicas, homologação
 * Método: axios + cheerio
 */
const axios = require("axios");
const cheerio = require("cheerio");
const { extrairData, isHoje, hojeStr } = require("../utils/date");
const log = require("../utils/logger");

const PORTAL = {
  nome: "BP-e Notícias",
  url: "https://dfe-portal.svrs.rs.gov.br/Bpe/Noticias",
};

const HEADERS = {
  "User-Agent": "Auditec-Curador/1.0 (Fiscal Compliance)",
  Accept: "text/html,application/xhtml+xml",
};

function autoTags(titulo) {
  const t = (titulo || "").toLowerCase();
  const tags = ["BP-e"];
  if (/nota\s+t[eé]cnica|nt\s+\d/i.test(t)) tags.push("NT");
  if (/schema|xsd/i.test(t)) tags.push("schema");
  if (/ibs/i.test(t)) tags.push("IBS");
  if (/cbs/i.test(t)) tags.push("CBS");
  if (/rtc|reforma/i.test(t)) tags.push("RTC");
  if (/homologa/i.test(t)) tags.push("homologação");
  if (/produ[çc][ãa]o/i.test(t)) tags.push("produção");
  if (/consulta\s+p[uú]blica/i.test(t)) tags.push("consulta pública");
  if (/valida/i.test(t)) tags.push("validação");
  return tags;
}

/**
 * Segmenta texto corrido do portal em blocos com data e título.
 */
function segmentarBlocos(texto) {
  const blocos = [];
  const partes = texto.split(/(?=\d{2}\/\d{2}\/\d{4})/);
  for (const parte of partes) {
    const t = parte.trim();
    if (!t || t.length < 15) continue;
    const data = extrairData(t);
    if (!data) continue;
    const semData = t.replace(/^\d{2}\/\d{2}\/\d{4}\s*[-–—:.]?\s*/, "");
    const titulo = semData.split(/[.\n]/, 1)[0].trim();
    if (titulo.length < 10) continue;
    blocos.push({ data, titulo, texto: semData.slice(0, 500) });
  }
  return blocos;
}

async function coletar() {
  const resultado = {
    nome: PORTAL.nome,
    url: PORTAL.url,
    consultadoEm: "",
    encontrouItensHoje: false,
    itens: [],
    observacoes: "",
    erro: null,
  };

  log.info(`Verificando ${PORTAL.nome}...`);

  let html;
  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      const resp = await axios.get(PORTAL.url, { headers: HEADERS, timeout: 30000 });
      html = resp.data;
      break;
    } catch (err) {
      if (attempt === 2) {
        resultado.erro = `Falha após 2 tentativas: ${err.message}`;
        log.error(`  ✗ ${PORTAL.nome}: ${resultado.erro}`);
        return resultado;
      }
      await new Promise((r) => setTimeout(r, 2000));
    }
  }

  resultado.consultadoEm = new Date().toISOString();

  try {
    const $ = cheerio.load(html);
    const seen = new Set();

    // Estratégia 1: links com data no contexto
    $("a[href]").each((_, el) => {
      const a = $(el);
      let href = (a.attr("href") || "").trim();
      const titulo = a.text().replace(/\s+/g, " ").trim();
      if (!titulo || titulo.length < 10 || seen.has(titulo)) return;
      seen.add(titulo);

      if (href.startsWith("/")) href = "https://dfe-portal.svrs.rs.gov.br" + href;
      const parent = a.closest("div, li, tr, article");
      let data = null;
      if (parent.length) data = extrairData(parent.text());
      if (!data) data = extrairData(titulo);

      if (data && isHoje(data)) {
        resultado.itens.push({
          titulo,
          dataPublicacao: data,
          url: href,
          resumoCurto: titulo.split(/\s+/).slice(0, 50).join(" "),
          tags: autoTags(titulo),
          portalOrigem: PORTAL.nome,
          tipoConteudo: /nota\s+t[eé]cnica/i.test(titulo) ? "nota técnica" : "comunicado",
          confianca: "alta",
        });
      }
    });

    // Estratégia 2: texto corrido
    if (resultado.itens.length === 0) {
      const content = $("main, #content, .content, body").first().text();
      for (const bloco of segmentarBlocos(content)) {
        if (!isHoje(bloco.data) || seen.has(bloco.titulo)) continue;
        seen.add(bloco.titulo);
        resultado.itens.push({
          titulo: bloco.titulo,
          dataPublicacao: bloco.data,
          url: PORTAL.url,
          resumoCurto: bloco.texto.split(/\s+/).slice(0, 50).join(" "),
          tags: autoTags(bloco.titulo),
          portalOrigem: PORTAL.nome,
          tipoConteudo: "comunicado",
          confianca: "média",
        });
      }
    }

    resultado.encontrouItensHoje = resultado.itens.length > 0;
    if (!resultado.encontrouItensHoje) {
      resultado.observacoes = `Portal verificado com sucesso. Sem publicações para ${hojeStr()}.`;
    }

    log.info(`  → ${PORTAL.nome}: ${resultado.itens.length} item(ns) de hoje`);
  } catch (err) {
    resultado.erro = `Erro no parsing: ${err.message}`;
    log.error(`  ✗ ${PORTAL.nome}: ${resultado.erro}`);
  }

  return resultado;
}

module.exports = { coletar };
