/**
 * PORTAL 3 — CGIBS Notícias
 * URL: https://www.cgibs.gov.br/noticias
 * Estrutura: página dinâmica, pode exibir 0 itens, cards com editorias
 * Método: Puppeteer (conteúdo carregado via JS)
 */
const puppeteer = require("puppeteer");
const { extrairData, isHoje, hojeStr } = require("../utils/date");
const log = require("../utils/logger");

const PORTAL = {
  nome: "CGIBS Notícias",
  url: "https://www.cgibs.gov.br/noticias",
};

function autoTags(titulo) {
  const t = (titulo || "").toLowerCase();
  const tags = [];
  if (/ibs/i.test(t)) tags.push("IBS");
  if (/cbs/i.test(t)) tags.push("CBS");
  if (/rtc|reforma/i.test(t)) tags.push("RTC");
  if (/comit[eê]\s*gestor|cgibs/i.test(t)) tags.push("CGIBS");
  if (/comunicado/i.test(t)) tags.push("comunicado");
  if (/cartilha|orienta/i.test(t)) tags.push("orientação");
  if (/nota\s+t[eé]cnica/i.test(t)) tags.push("NT");
  return tags.length ? tags : ["CGIBS", "IBS"];
}

async function coletar() {
  const resultado = {
    nome: PORTAL.nome,
    url: PORTAL.url,
    consultadoEm: "",
    encontrouItensHoje: false,
    itens: [],
    observacoes: "",
    erro: null,
  };

  log.info(`Verificando ${PORTAL.nome}...`);
  let browser;

  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      browser = await puppeteer.launch({
        headless: "new",
        args: ["--no-sandbox", "--disable-setuid-sandbox"],
      });
      const page = await browser.newPage();
      await page.setUserAgent("Auditec-Curador/1.0 (Fiscal Compliance)");
      await page.goto(PORTAL.url, { waitUntil: "networkidle2", timeout: 30000 });

      // Esperar conteúdo carregar
      await page.waitForTimeout(3000);

      resultado.consultadoEm = new Date().toISOString();

      // Extrair conteúdo da página
      const dados = await page.evaluate(() => {
        const items = [];

        // Verificar se página mostra "0 itens"
        const bodyText = document.body.innerText;
        if (/exibindo\s+0\s+a\s+0\s+de\s+0/i.test(bodyText)) {
          return { vazio: true, items: [] };
        }

        // Tentar capturar cards/links de notícias
        const seletores = [
          "article", ".card", ".news-item", ".post",
          ".listagem-item", "li.item", ".resultado",
        ];

        for (const sel of seletores) {
          document.querySelectorAll(sel).forEach((el) => {
            const a = el.querySelector("a[href]");
            if (!a) return;
            const titulo = (a.textContent || "").trim();
            const href = a.href || "";
            if (!titulo || titulo.length < 10) return;

            // Buscar data
            let data = "";
            const timeEl = el.querySelector("time, .date, .data, span.date");
            if (timeEl) {
              data = (timeEl.getAttribute("datetime") || timeEl.textContent || "").trim();
            }
            if (!data) {
              const txt = el.textContent || "";
              const m = txt.match(/(\d{2}\/\d{2}\/\d{4})/);
              if (m) data = m[1];
            }

            // Resumo
            const pEl = el.querySelector("p, .resumo, .excerpt, .descricao");
            const resumo = pEl ? (pEl.textContent || "").trim().slice(0, 300) : "";

            items.push({ titulo, href, data, resumo });
          });
        }

        // Fallback: buscar links diretamente no conteúdo principal
        if (items.length === 0) {
          const main = document.querySelector("main, #content, .content, .main-content");
          if (main) {
            main.querySelectorAll("a[href]").forEach((a) => {
              const titulo = (a.textContent || "").trim();
              const href = a.href || "";
              if (!titulo || titulo.length < 15) return;
              if (/login|cadastr|contato|sobre|menu/i.test(href)) return;

              const parent = a.closest("li, div, article");
              let data = "";
              if (parent) {
                const m = parent.textContent.match(/(\d{2}\/\d{2}\/\d{4})/);
                if (m) data = m[1];
              }

              items.push({ titulo, href, data, resumo: "" });
            });
          }
        }

        return { vazio: false, items };
      });

      // Processar resultados
      if (dados.vazio) {
        resultado.observacoes = `Portal verificado. Página exibiu "0 itens" para ${hojeStr()}.`;
      } else {
        for (const item of dados.items) {
          const data = extrairData(item.data);
          if (!data || !isHoje(data)) continue;

          let href = item.href;
          if (href.startsWith("/")) href = "https://www.cgibs.gov.br" + href;

          resultado.itens.push({
            titulo: item.titulo.replace(/\s+/g, " "),
            dataPublicacao: data,
            url: href,
            resumoCurto: (item.resumo || item.titulo).split(/\s+/).slice(0, 50).join(" "),
            tags: autoTags(item.titulo),
            portalOrigem: PORTAL.nome,
            tipoConteudo: /comunicado/i.test(item.titulo) ? "comunicado" : "publicação institucional",
            confianca: "média",
          });
        }

        resultado.encontrouItensHoje = resultado.itens.length > 0;
        if (!resultado.encontrouItensHoje) {
          resultado.observacoes = `Portal verificado com sucesso. Sem publicações para ${hojeStr()}.`;
        }
      }

      log.info(`  → ${PORTAL.nome}: ${resultado.itens.length} item(ns) de hoje`);
      break; // Sucesso, sai do retry
    } catch (err) {
      if (attempt === 2) {
        resultado.erro = `Falha após 2 tentativas: ${err.message}`;
        log.error(`  ✗ ${PORTAL.nome}: ${resultado.erro}`);
      } else {
        log.warn(`  ⏱ ${PORTAL.nome}: tentativa ${attempt} falhou, retentando...`);
        await new Promise((r) => setTimeout(r, 3000));
      }
    } finally {
      if (browser) await browser.close().catch(() => {});
    }
  }

  return resultado;
}

module.exports = { coletar };
