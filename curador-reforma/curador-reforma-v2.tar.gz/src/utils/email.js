/**
 * Email — envio de resumo diário via Gmail SMTP
 */
const nodemailer = require("nodemailer");
const { hojeStr, agoraISO } = require("./date");
const log = require("./logger");

/**
 * Envia email-resumo da curadoria diária.
 * SEMPRE envia, mesmo com 0 itens.
 */
async function enviarResumo(resultado) {
  const user = process.env.EMAIL_USER;
  const pass = process.env.EMAIL_PASS;
  const to = process.env.EMAIL_TO;

  if (!user || !pass || !to) {
    log.warn("Email não enviado: EMAIL_USER, EMAIL_PASS ou EMAIL_TO não configurados.");
    return false;
  }

  if (process.env.DRY_RUN === "true") {
    log.info("DRY_RUN ativo — email suprimido.");
    return false;
  }

  try {
    const transporter = nodemailer.createTransport({
      host: "smtp.gmail.com",
      port: 587,
      secure: false,
      auth: { user, pass },
    });

    const hoje = hojeStr();
    const total = resultado.totalItens || 0;
    const portais = resultado.portais || [];
    const erros = resultado.erros || [];

    // Corpo HTML
    let linhasPortais = "";
    for (const p of portais) {
      const status = p.encontrouItensHoje
        ? `<span style="color:#27ae60;font-weight:700;">✓ ${p.itens.length} publicação(ões)</span>`
        : `<span style="color:#888;">— Sem novidades</span>`;
      const obs = p.observacoes ? `<br><small style="color:#999;">${p.observacoes}</small>` : "";
      const itensList = (p.itens || [])
        .map(
          (it) =>
            `<li style="margin:4px 0;"><strong>${it.titulo}</strong><br><small style="color:#666;">${(it.tags || []).join(", ")} · ${it.tipoConteudo || ""}</small></li>`
        )
        .join("");
      const itensHtml = itensList ? `<ul style="margin:6px 0 0 16px;padding:0;">${itensList}</ul>` : "";

      linhasPortais += `
        <tr>
          <td style="padding:10px 14px;border-bottom:1px solid #e0dcd4;vertical-align:top;">
            <div style="font-weight:600;font-size:14px;color:#1a1a1a;margin-bottom:3px;">${p.nome}</div>
            <div style="font-size:12px;">${status}${obs}</div>
            ${itensHtml}
          </td>
        </tr>`;
    }

    let errosHtml = "";
    if (erros.length > 0) {
      errosHtml = `
        <div style="margin-top:16px;padding:10px 14px;background:rgba(231,76,60,0.08);border-left:3px solid #e74c3c;border-radius:4px;">
          <strong style="color:#e74c3c;">Erros na execução:</strong>
          <ul style="margin:6px 0 0 16px;font-size:12px;color:#c0392b;">
            ${erros.map((e) => `<li>${e}</li>`).join("")}
          </ul>
        </div>`;
    }

    const html = `
<!DOCTYPE html>
<html lang="pt-BR"><head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#f0ede6;font-family:'Segoe UI',Helvetica,sans-serif;">
<div style="max-width:620px;margin:20px auto;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,0.08);">
  <div style="background:linear-gradient(135deg,#a17c2f,#c9a23d);padding:22px 28px;text-align:center;">
    <div style="font-size:22px;font-weight:800;color:#fff;letter-spacing:2px;">TERA</div>
    <div style="font-size:11px;color:rgba(255,255,255,0.85);letter-spacing:1px;margin-top:2px;">REFORMA EM DIA — Curadoria Diária</div>
  </div>
  <div style="padding:22px 28px;">
    <p style="font-size:14px;color:#1a1a1a;margin:0 0 14px;">
      Verificação de <strong>${hoje}</strong> concluída às ${agoraISO().split(" ")[1]} BRT.
    </p>
    <div style="display:flex;gap:16px;margin-bottom:16px;">
      <div style="flex:1;background:#f5f3ee;border-radius:8px;padding:12px;text-align:center;">
        <div style="font-size:28px;font-weight:800;color:#a17c2f;">${total}</div>
        <div style="font-size:11px;color:#666;">publicações hoje</div>
      </div>
      <div style="flex:1;background:#f5f3ee;border-radius:8px;padding:12px;text-align:center;">
        <div style="font-size:28px;font-weight:800;color:#a17c2f;">${resultado.totalPortaisVerificados || 0}</div>
        <div style="font-size:11px;color:#666;">portais verificados</div>
      </div>
    </div>
    <table style="width:100%;border-collapse:collapse;border:1px solid #e0dcd4;border-radius:8px;overflow:hidden;">
      <thead><tr><th style="padding:10px 14px;background:#a17c2f;color:#fff;text-align:left;font-size:13px;">Portal</th></tr></thead>
      <tbody>${linhasPortais}</tbody>
    </table>
    ${errosHtml}
    <p style="font-size:10px;color:#999;margin:18px 0 0;border-top:1px solid #e0dcd4;padding-top:14px;">
      Email automático do TERA — Curador Reforma Tributária.<br>
      Execução: ${agoraISO()} BRT.
    </p>
  </div>
</div>
</body></html>`;

    // Texto plano
    let textoPlano = `TERA — Reforma em Dia\nVerificação: ${hoje}\n\n`;
    for (const p of portais) {
      textoPlano += `${p.encontrouItensHoje ? "✓" : "—"} ${p.nome}: ${p.itens.length} item(ns)\n`;
      for (const it of p.itens) textoPlano += `  • ${it.titulo}\n`;
    }
    if (erros.length) textoPlano += `\nErros: ${erros.join(", ")}\n`;

    const info = await transporter.sendMail({
      from: user,
      to,
      subject: `Reforma Tributária — Verificação ${hoje} · ${total} publicação(ões)`,
      text: textoPlano,
      html,
    });

    log.ok(`Email enviado para ${to} (${info.messageId})`);
    return true;
  } catch (err) {
    log.error(`Falha no email: ${err.message}`);
    return false;
  }
}

module.exports = { enviarResumo };
