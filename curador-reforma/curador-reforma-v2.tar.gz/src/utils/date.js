/**
 * Utilitário de datas — timezone America/Sao_Paulo
 * Normaliza datas DD/MM/YYYY, ISO, e texto brasileiro.
 */
const dayjs = require("dayjs");
const utc = require("dayjs/plugin/utc");
const timezone = require("dayjs/plugin/timezone");
const customParseFormat = require("dayjs/plugin/customParseFormat");

dayjs.extend(utc);
dayjs.extend(timezone);
dayjs.extend(customParseFormat);

const TZ = process.env.TIMEZONE || "America/Sao_Paulo";

/** Data atual em BRT no formato DD/MM/YYYY */
function hojeStr() {
  return dayjs().tz(TZ).format("DD/MM/YYYY");
}

/** Data atual em BRT no formato YYYY-MM-DD (para pastas e JSON) */
function hojeISO() {
  return dayjs().tz(TZ).format("YYYY-MM-DD");
}

/** Timestamp completo em BRT */
function agoraISO() {
  return dayjs().tz(TZ).format("DD/MM/YYYY HH:mm:ss");
}

/**
 * Extrai data DD/MM/YYYY de um texto.
 * Retorna a primeira data encontrada ou null.
 */
function extrairData(texto) {
  if (!texto) return null;

  // DD/MM/YYYY
  const m1 = texto.match(/(\d{2})\/(\d{2})\/(\d{4})/);
  if (m1) return `${m1[1]}/${m1[2]}/${m1[3]}`;

  // YYYY-MM-DD (ISO)
  const m2 = texto.match(/(\d{4})-(\d{2})-(\d{2})/);
  if (m2) return `${m2[3]}/${m2[2]}/${m2[1]}`;

  // DD de mês de YYYY
  const meses = {
    janeiro: "01", fevereiro: "02", março: "03", marco: "03",
    abril: "04", maio: "05", junho: "06", julho: "07",
    agosto: "08", setembro: "09", outubro: "10",
    novembro: "11", dezembro: "12",
  };
  const m3 = texto.match(/(\d{1,2})\s+de\s+(\w+)\s+de\s+(\d{4})/i);
  if (m3) {
    const mes = meses[m3[2].toLowerCase()];
    if (mes) return `${m3[1].padStart(2, "0")}/${mes}/${m3[3]}`;
  }

  return null;
}

/**
 * Verifica se uma data DD/MM/YYYY corresponde ao dia de hoje (BRT).
 */
function isHoje(dataStr) {
  if (!dataStr) return false;
  return dataStr === hojeStr();
}

/**
 * Converte DD/MM/YYYY para YYYY-MM-DD
 */
function brParaISO(dataStr) {
  if (!dataStr) return "";
  const [d, m, y] = dataStr.split("/");
  return `${y}-${m}-${d}`;
}

module.exports = { hojeStr, hojeISO, agoraISO, extrairData, isHoje, brParaISO, TZ };
