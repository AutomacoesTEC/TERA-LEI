/**
 * Logger — console + arquivo em ./logs/curador.log
 */
const fs = require("fs");
const path = require("path");
const { agoraISO } = require("./date");

const LOG_DIR = path.join(process.cwd(), "logs");
const LOG_FILE = path.join(LOG_DIR, "curador.log");

function ensureDir() {
  if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });
}

function write(level, msg) {
  const ts = agoraISO();
  const line = `[${ts}] [${level}] ${msg}`;
  console.log(line);
  try {
    ensureDir();
    fs.appendFileSync(LOG_FILE, line + "\n", "utf-8");
  } catch (_) {}
}

module.exports = {
  info: (msg) => write("INFO", msg),
  warn: (msg) => write("WARN", msg),
  error: (msg) => write("ERRO", msg),
  ok: (msg) => write(" OK ", msg),
  separator: () => write("────", "─".repeat(60)),
};
