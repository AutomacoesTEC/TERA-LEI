#!/usr/bin/env node
/**
 * ═══════════════════════════════════════════════════════════════════════
 * TERA — Curador Reforma Tributária v2.0
 * ═══════════════════════════════════════════════════════════════════════
 *
 * Agente diário de curadoria de publicações da Reforma Tributária do
 * Consumo (IBS/CBS/IS/RTC). Monitora 7 portais oficiais com parsers
 * dedicados por portal.
 *
 * Execução: diariamente às 19:00 BRT (cron ou GitHub Actions)
 * Saída: ./pendente-publicacao/YYYY-MM-DD/pendente.json
 * Email: resumo diário SEMPRE enviado (mesmo com 0 itens)
 *
 * Portais monitorados:
 *   1. CT-e Informes
 *   2. NF-e Notas Técnicas
 *   3. CGIBS Notícias
 *   4. MDF-e Notícias
 *   5. NFABI Documentos
 *   6. BP-e Notícias
 *   7. NFS-e RTC
 *
 * Stack: Node.js 20+, Puppeteer, Cheerio, Axios, Nodemailer, dayjs
 * ═══════════════════════════════════════════════════════════════════════
 */

require("dotenv").config();

const fs = require("fs");
const path = require("path");
const log = require("./src/utils/logger");
const { hojeStr, hojeISO, agoraISO } = require("./src/utils/date");
const { enviarResumo } = require("./src/utils/email");

// Parsers dedicados por portal
const parsers = [
  { name: "CT-e", mod: require("./src/parsers/cte") },
  { name: "NF-e", mod: require("./src/parsers/nfe") },
  { name: "CGIBS", mod: require("./src/parsers/cgibs") },
  { name: "MDF-e", mod: require("./src/parsers/mdfe") },
  { name: "NFABI", mod: require("./src/parsers/nfabi") },
  { name: "BP-e", mod: require("./src/parsers/bpe") },
  { name: "NFS-e RTC", mod: require("./src/parsers/nfseRtc") },
];

// Delay entre portais (respeitar limites)
const DELAY_MS = 2500;

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function main() {
  log.separator();
  log.info(`═══ TERA Curador Reforma v2.0 — ${agoraISO()} ═══`);
  log.info(`Data alvo: ${hojeStr()}`);
  log.info(`Portais a verificar: ${parsers.length}`);
  log.separator();

  const resultado = {
    dataVerificacao: hojeStr(),
    dataExecucao: agoraISO(),
    portais: [],
    totalItens: 0,
    totalPortaisVerificados: 0,
    totalPortaisComItens: 0,
    totalPortaisSemItens: 0,
    erros: [],
  };

  // Executar cada parser sequencialmente com delay
  for (let i = 0; i < parsers.length; i++) {
    const { name, mod } = parsers[i];

    try {
      const portal = await mod.coletar();
      resultado.portais.push(portal);
      resultado.totalPortaisVerificados++;

      if (portal.encontrouItensHoje) {
        resultado.totalPortaisComItens++;
        resultado.totalItens += portal.itens.length;
      } else {
        resultado.totalPortaisSemItens++;
      }

      if (portal.erro) {
        resultado.erros.push(`${name}: ${portal.erro}`);
      }
    } catch (err) {
      log.error(`Erro fatal em ${name}: ${err.message}`);
      resultado.erros.push(`${name}: erro fatal — ${err.message}`);
      resultado.portais.push({
        nome: name,
        url: "",
        consultadoEm: new Date().toISOString(),
        encontrouItensHoje: false,
        itens: [],
        observacoes: "",
        erro: `Erro fatal: ${err.message}`,
      });
      resultado.totalPortaisVerificados++;
      resultado.totalPortaisSemItens++;
    }

    // Delay entre portais (exceto o último)
    if (i < parsers.length - 1) {
      await sleep(DELAY_MS);
    }
  }

  // ── Salvar JSON ───────────────────────────────────────────
  if (process.env.DRY_RUN !== "true") {
    const dir = path.join(process.cwd(), "pendente-publicacao", hojeISO());
    fs.mkdirSync(dir, { recursive: true });

    const jsonPath = path.join(dir, "pendente.json");
    fs.writeFileSync(jsonPath, JSON.stringify(resultado, null, 2), "utf-8");
    log.ok(`JSON salvo em ${jsonPath}`);

    // Também salvar versão para integração com TERA (data/reforma_curadoria.json)
    const dataDir = path.join(process.cwd(), "data");
    if (fs.existsSync(dataDir)) {
      const teraPath = path.join(dataDir, "reforma_curadoria.json");
      fs.writeFileSync(teraPath, JSON.stringify(resultado, null, 2), "utf-8");
      log.ok(`Cópia TERA salva em ${teraPath}`);
    }
  } else {
    log.info("DRY_RUN ativo — JSON não salvo.");
    console.log(JSON.stringify(resultado, null, 2));
  }

  // ── Enviar email (SEMPRE) ─────────────────────────────────
  await enviarResumo(resultado);

  // ── Relatório final ───────────────────────────────────────
  log.separator();
  log.info("═══ RELATÓRIO FINAL ═══");
  log.info(`  Portais verificados: ${resultado.totalPortaisVerificados}`);
  log.info(`  Com publicações hoje: ${resultado.totalPortaisComItens}`);
  log.info(`  Sem publicações hoje: ${resultado.totalPortaisSemItens}`);
  log.info(`  Total de itens: ${resultado.totalItens}`);

  if (resultado.erros.length > 0) {
    log.warn(`  Erros: ${resultado.erros.length}`);
    for (const e of resultado.erros) log.warn(`    ✗ ${e}`);
  }

  for (const p of resultado.portais) {
    const status = p.encontrouItensHoje
      ? `✓ ${p.itens.length} item(ns)`
      : p.erro
        ? `✗ ERRO`
        : `— sem novidades`;
    log.info(`  ${status.padEnd(20)} ${p.nome}`);
  }

  log.separator();
  log.ok("Curadoria concluída.");

  return resultado;
}

// ── Execução ────────────────────────────────────────────────
main()
  .then(() => process.exit(0))
  .catch((err) => {
    log.error(`ERRO FATAL NA EXECUÇÃO: ${err.message}`);
    console.error(err);
    process.exit(1);
  });
