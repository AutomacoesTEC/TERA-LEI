# TERA — Curador Reforma Tributária v2.0

Agente diário de curadoria de publicações da **Reforma Tributária do Consumo** (IBS/CBS/IS/RTC).

Monitora 7 portais oficiais com parsers dedicados, gera JSON pronto para publicação no TERA e envia email-resumo diário.

## Portais Monitorados

| # | Portal | URL | Método |
|---|--------|-----|--------|
| 1 | CT-e Informes | cte.fazenda.gov.br | cheerio |
| 2 | NF-e Notas Técnicas | nfe.fazenda.gov.br | cheerio |
| 3 | CGIBS Notícias | cgibs.gov.br | puppeteer |
| 4 | MDF-e Notícias | dfe-portal.svrs.rs.gov.br | cheerio |
| 5 | NFABI Documentos | dfe-portal.svrs.rs.gov.br | cheerio |
| 6 | BP-e Notícias | dfe-portal.svrs.rs.gov.br | cheerio |
| 7 | NFS-e RTC | gov.br/nfse | cheerio |

## Setup

```bash
# Instalar dependências
npm install

# Configurar variáveis de ambiente
cp .env.example .env
# Editar .env com credenciais reais

# Executar
npm start

# Executar em modo teste (sem email, sem salvar)
npm run test:dry
```

## Variáveis de Ambiente

| Variável | Descrição |
|----------|-----------|
| `EMAIL_USER` | Email Gmail remetente |
| `EMAIL_PASS` | App Password do Gmail |
| `EMAIL_TO` | Email destinatário |
| `TIMEZONE` | Fuso horário (default: America/Sao_Paulo) |
| `DRY_RUN` | Se `true`, não envia email nem salva JSON |

## Cron (Linux/VPS)

```cron
# Executar às 19:00 BRT diariamente
0 19 * * * cd /caminho/curador-reforma && node curador-reforma.js >> logs/cron.log 2>&1
```

## GitHub Actions

Adicionar workflow `.github/workflows/curadoria_reforma.yml` com:

```yaml
on:
  schedule:
    - cron: '0 22 * * *'  # 19h BRT = 22h UTC
```

## Estrutura de Saída

```
./pendente-publicacao/
  2026-04-14/
    pendente.json
  2026-04-15/
    pendente.json
./logs/
  curador.log
./data/
  reforma_curadoria.json   # Cópia para integração TERA
```

## Formato JSON

```json
{
  "dataVerificacao": "14/04/2026",
  "dataExecucao": "14/04/2026 19:00:00",
  "portais": [
    {
      "nome": "CT-e Informes",
      "url": "https://www.cte.fazenda.gov.br/portal/informe.aspx",
      "consultadoEm": "2026-04-14T22:00:05.123Z",
      "encontrouItensHoje": false,
      "itens": [],
      "observacoes": "Portal verificado com sucesso. Sem publicações para 14/04/2026.",
      "erro": null
    }
  ],
  "totalItens": 0,
  "totalPortaisVerificados": 7,
  "totalPortaisComItens": 0,
  "totalPortaisSemItens": 7,
  "erros": []
}
```

## Fluxo de Aprovação

1. Curador executa às 19h e gera `pendente-publicacao/YYYY-MM-DD/pendente.json`
2. Email-resumo é enviado automaticamente
3. Responsável revisa os itens encontrados
4. Itens aprovados podem ser transferidos para `data/reforma_em_dia.json` no TERA

## Arquitetura

```
curador-reforma.js          # Orquestrador principal
src/
  parsers/
    cte.js                  # Parser CT-e (cheerio)
    nfe.js                  # Parser NF-e (cheerio)
    cgibs.js                # Parser CGIBS (puppeteer)
    mdfe.js                 # Parser MDF-e (cheerio)
    nfabi.js                # Parser NFABI (cheerio)
    bpe.js                  # Parser BP-e (cheerio)
    nfseRtc.js              # Parser NFS-e RTC (cheerio)
  utils/
    date.js                 # Datas com timezone BRT
    email.js                # Nodemailer + template HTML
    logger.js               # Console + arquivo de log
```

## Notas

- Cada portal tem parser próprio com regras e heurísticas específicas
- Delay de 2.5s entre portais para evitar bloqueios
- Retry de 2 tentativas por portal em caso de falha transitória
- Se um portal falhar, os demais continuam normalmente
- Email é SEMPRE enviado, mesmo com 0 publicações
- Resumos curtos limitados a 50 palavras, sem opinião jurídica
